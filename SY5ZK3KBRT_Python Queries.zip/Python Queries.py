print("1) Eligibility Criteria by using relational operators")
m=72
p=65
c=50
x= m>=60 and p>=50 and c>=45 and (m+p+c)>=180
y=(m+p)>=120 or (c+p)>=110
print(x or y)

print("2) Arithmatic operators: Write a progrrame that reads input and prints the number of 2000,500,200,50,20 and 1 Rs note required")
a=2257
no_of_2000=int(a/2000)
R=a%2000
no_of_500= int(R/500)
R=R%500
no_of_200= int(R/200)
R=R%200
no_of_50= int(R/50)
R=R%50
no_of_20= int(R/20)
R=R%20
no_of_1= int(R/1)
R=R%1
print("2000:"+str(no_of_2000)+" 500:"+str(no_of_500)+" 200:"+str(no_of_200)+" 50:"+str(no_of_50)+" 20:"+str(no_of_20)+" 1:"+str(no_of_1))
print("3)While loop: Product of N numbers after x")
x=4
n=2
counter=1
product=1
while counter<=n:
    a=x+counter
    product=product*a 
    counter+=1 
print("Ans:"+str(product))
print("4) Some of the N Squres")
a=7
counter=1
x=0 
while counter<=a: 
    squre=counter**2
    x=x+squre
    counter=counter+1 
print(x)

print("5) Rectangle using for loop")
m=4
n=5
for c in range(1, (m+1)):
    x=str(c)+" "
    print(x*n)
    
print("6) print the count of Vovels in the given word ")
m="Devoloper"
count=0
for c in m:
    if c in("a", "e", "i","o","u") or ("A","E","I","O","U"):
        count=count+1
print(count)
print("7) print Odd Numbers from n to m")
m=1
n=10
total=n-m
odd=""
for c in range(total+1):
    number=n-c 
    if number%2!=0:
        odd=odd+str(number)+" "
print(odd)
print("8) Find the power of the Number without using **")
n=2 
m=3
total=1
for c in range(m):
    total=total*n
print(total)
print("9) least numberby using Break: Either given number is divisible by 2-10 numbers")
n=5
for c in range(2, 10):
    if n%c==0:
        print("Divisible Number")
        break 
else:
    print("Indivisible Number")

print("10) Smalllest among the given numbers")
n=5
first_input=8
smallest_no=first_input
for c in range(n-1):
    if n<smallest_no:
        smallest_no=n
print(smallest_no)
print("11) Sum of the n terms in m square series")
m=4
n=3
some=0
for c in range(1, n+1):
    x=int(m*c)**2
    some=some+(x)
print(some)

print("12) print the count of pythogonous triplets containing a, b, c from 1 to n(a**2+b**2=c**2)")
n=20  
count=0
for a in range(1,n+1):
    for b in range(a+1,n+1):
        for c in range(b+1,n+1):
            if (a**2+b**2)==c**2 and a<b<c:
                count+=1 
print(count)   

print("13) Artmstrong number between two intervals")
m=300
n=500 
res=""
count=0
for num in range(m,n+1):
    l=(len(str(num)))
    sume=0
    for digit in (str(num)):  # c in python gives p,y,t,h,o,n
        sume+=(int(digit)**l) 
    if sume==(num):
        count=count+1 
        res+=str(num)+" "
if count>0:
    print(res)
else:
    print("-1")
print("14) print the pyramid with k rows starting from n in reverse")
n=10 
k=5
count=0
for rows in range(1,k+1):
    count+=rows
    num=n+count-1
for rows in range(1,k+1):
    res=""
    for col in range(1,rows+1):
        res=res+str(num)+" "
        num=num-1
    print(res)
print("15) Some of the prime numbers in range")
m=3 
n=7 
some=0
for row in range(m,n+1):
    c=0 
    for i in range(1,row+1):
        if row%i==0:
            c+=1 
    if c==2:
        some+=row 
print(some)
print("16) print butterfly with stars")
n=4
for row in range(1,n+1):
    mspace="  "*(n-row)
    string="* "*row+2*mspace+"* "*row
    print(string)
for row2 in range(1,n+1):
    mspace="  "*(row2-1)
    string="* "*(n-row2+1)+2*mspace+"* "*(n-row2+1)
    print(string)
print("17) print alphabates in hollow rectangle")    
m=4
n=6
x="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
q=0
for row in range(1,m+1):
    res=""
    if row==1 or row==m:
        for col in range(1,n+1):
            res=res+x[q]+" "
            q=q+1
    else:
        res=x[q]
        space=" "*(2*(n-2))
        q=q+int(len(space)/2)+1
        res=res+" "+space+x[q]+" "
        q=q+1
    print(res)
print("18) Covert First word in sentence to uppercase")
a="Python is a good language"
word=""
index=0 
for i in (a):
    if i==" ":
        break 
    word+=i #python will print
    index+=1 #will give last index of word python 
print(word.upper()+a[index:]) #so if we start with dat index will get remain sentence.     

print("19) write programe to print new sen by removing vowels ")
s="Speak Louder"
res=""
for i in (s):
    if i=="a" or i=="i"or i=="o" or i=="e" or i=="u"or i=="A" or i=="I"or i=="O" or i=="E" or i=="U" :
        continue
    res+=i
print(res)
print("20) programme to convert given string camel case to snake case")
a="PythonLearning"
res=""
index=a[0]
x=1
for i in (a):
    if i==i.upper():
        res=res+"_"+i.lower()
    else:
        res+=i
print(res[1:])
print("20) write programme to check the second string is subsequence of first string")    
a="Google"
b="ole"
l=len(b)
index=0
for i in (a):
    if i==b[index]:
        index+=1 
        if index==l:
            break 
if index==l:
    print("Yes")
else:
    print("No")

print("22) List concatenation")
L = ["apple", "78", "970.03"]
n=2
res=[]
for i in range(n):
    x="1235"
    res+=[x]
print(L+res)
print("23) Swap elements in the list")
L = [1, "two", 9, 5.09, "Three", -558, "four", -93.7, "six"]
m=2
n=6
a=L[m]
b=L[n]
L[m]=b
L[n]=a
print(L)

print("24) ATM PIN code Validation ")
def validate_atm_pin_code(pin):
    digit= len(pin)==4 or len(pin)==6 
    valid="True"
    for i in (pin):
        if not(i.isdigit()):
            valid="False"
    if valid and digit:
        res="Valid PIN Code"
    else:
        res="Invalid PIN Code"
    print(res)
pin ="9837"
validate_atm_pin_code(pin)
# Call the validate_atm_pin_code function

print("25) Factors of the number by using function")
def factors_of_n(number):
    res=""
    for i in range(1,number+1):
        if number%i==0:
            res+=str(i)+" "
    return res 
number = 6
result =factors_of_n(number) # call the factors_of_n function
print(result)